#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import cv2
import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]


@dataclass
class Track:
    track_id: int
    left_point: np.ndarray
    point_3d: np.ndarray
    world_point: np.ndarray | None = None
    image_velocity: np.ndarray | None = None
    age: int = 1


@dataclass
class PoseRow:
    frame_index: int
    timestamp_sec: float
    success: bool
    position: np.ndarray
    rotation: np.ndarray
    pose_inliers: int
    pose_inlier_ratio: float
    active_tracks: int
    stereo_tracks: int
    note: str


def main() -> None:
    args = parse_args()
    result = run(args)
    print(json.dumps(result, ensure_ascii=False, indent=2))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "ROS2-native stereo+IMU VIO frontend. It uses only synchronized stereo images "
            "and IMU samples exported from a ROS2 bag; DVL is not consumed."
        )
    )
    parser.add_argument(
        "--dataset-dir",
        type=Path,
        required=True,
        help="Directory containing image_0, image_1, times.txt, imu.csv, metadata.json.",
    )
    parser.add_argument("--output-csv", type=Path, default=PROJECT_ROOT / "outputs" / "live" / "latest_ros2_stereo_imu_vio.csv")
    parser.add_argument("--summary-json", type=Path, default=PROJECT_ROOT / "outputs" / "evaluation" / "ros2_stereo_imu_vio_summary.json")
    parser.add_argument("--debug-csv", type=Path, default=PROJECT_ROOT / "outputs" / "evaluation" / "ros2_stereo_imu_vio_debug.csv")
    parser.add_argument("--max-frames", type=int, default=0, help="0 uses every exported frame.")
    parser.add_argument("--max-features", type=int, default=320)
    parser.add_argument("--min-features", type=int, default=144)
    parser.add_argument("--quality", type=float, default=0.01)
    parser.add_argument("--min-distance", type=int, default=24)
    parser.add_argument("--block-size", type=int, default=7)
    parser.add_argument(
        "--feature-detector",
        choices=["gftt", "harris", "fast", "orb"],
        default="gftt",
        help="Feature detector used to seed KLT tracks. gftt is Shi-Tomasi.",
    )
    parser.add_argument("--fast-threshold", type=int, default=20)
    parser.add_argument("--orb-fast-threshold", type=int, default=20)
    parser.add_argument(
        "--reject-repeated-patches",
        action="store_true",
        help="Reject features whose local image patch is too similar to nearby patches.",
    )
    parser.add_argument("--patch-size", type=int, default=13)
    parser.add_argument("--patch-search-radius", type=int, default=80)
    parser.add_argument("--patch-search-stride", type=int, default=8)
    parser.add_argument("--patch-ncc-threshold", type=float, default=0.92)
    parser.add_argument("--patch-min-std", type=float, default=6.0)
    parser.add_argument("--grid-rows", type=int, default=4)
    parser.add_argument("--grid-cols", type=int, default=6)
    parser.add_argument("--cell-max-features", type=int, default=18)
    parser.add_argument("--klt-window", type=int, default=21)
    parser.add_argument("--klt-levels", type=int, default=3)
    parser.add_argument("--klt-iterations", type=int, default=30)
    parser.add_argument("--klt-eps", type=float, default=0.01)
    parser.add_argument("--fb-threshold", type=float, default=0.8)
    parser.add_argument("--klt-max-error", type=float, default=0.0, help="0 disables LK patch-error filtering for temporal tracking.")
    parser.add_argument("--klt-max-flow-px", type=float, default=0.0, help="0 disables max optical-flow length filtering.")
    parser.add_argument("--klt-min-eigenvalue", type=float, default=0.0, help="0 disables current-frame texture filtering.")
    parser.add_argument("--klt-patch-size", type=int, default=15)
    parser.add_argument("--klt-patch-ncc-threshold", type=float, default=0.0, help="0 disables patch NCC filtering.")
    parser.add_argument("--klt-local-flow-check", action="store_true")
    parser.add_argument("--klt-local-flow-mad-factor", type=float, default=3.5)
    parser.add_argument("--klt-local-flow-min-abs", type=float, default=2.5)
    parser.add_argument("--klt-local-flow-min-points", type=int, default=8)
    parser.add_argument("--klt-use-prediction", action="store_true")
    parser.add_argument("--klt-velocity-check", action="store_true")
    parser.add_argument("--klt-max-accel-px", type=float, default=25.0)
    parser.add_argument("--min-track-age-for-pnp", type=int, default=1)
    parser.add_argument(
        "--temporal-ransac",
        choices=["none", "essential", "fundamental"],
        default="none",
        help=(
            "Optional frame-to-frame geometry check after KLT and before PnP. "
            "This rejects repeated-pattern optical-flow matches without using reference odometry."
        ),
    )
    parser.add_argument("--temporal-ransac-threshold", type=float, default=1.0)
    parser.add_argument("--temporal-ransac-confidence", type=float, default=0.999)
    parser.add_argument("--min-temporal-inliers", type=int, default=24)
    parser.add_argument("--stereo-fb-threshold", type=float, default=1.2)
    parser.add_argument("--stereo-max-error", type=float, default=0.0, help="0 disables LK patch-error filtering for left-right stereo matching.")
    parser.add_argument("--epipolar-threshold", type=float, default=2.0)
    parser.add_argument("--stereo-disparity-consistency", action="store_true")
    parser.add_argument("--stereo-disparity-mad-factor", type=float, default=3.5)
    parser.add_argument("--stereo-disparity-min-abs", type=float, default=2.0)
    parser.add_argument("--stereo-disparity-min-points", type=int, default=8)
    parser.add_argument("--min-disparity", type=float, default=1.5)
    parser.add_argument("--max-disparity", type=float, default=160.0)
    parser.add_argument("--min-depth", type=float, default=0.15)
    parser.add_argument("--max-depth", type=float, default=18.0)
    parser.add_argument(
        "--depth-scale",
        type=float,
        default=1.0,
        help=(
            "Multiplier applied to stereo-triangulated 3D points before PnP. "
            "Use this to test effective underwater stereo calibration without feeding reference odometry into VIO."
        ),
    )
    parser.add_argument(
        "--stereo-depth-mode",
        choices=["klt", "sgbm", "hybrid"],
        default="klt",
        help="hybrid uses KLT stereo first and fills missing depths from dense SGBM disparity.",
    )
    parser.add_argument("--sgbm-num-disparities", type=int, default=160)
    parser.add_argument("--sgbm-block-size", type=int, default=5)
    parser.add_argument("--sgbm-uniqueness", type=int, default=8)
    parser.add_argument("--sgbm-sample-radius", type=int, default=2)
    parser.add_argument(
        "--sgbm-fallback-min-klt",
        type=int,
        default=24,
        help="In hybrid mode, use SGBM only when KLT stereo returns fewer valid depths than this.",
    )
    parser.add_argument("--pnp-threshold", type=float, default=2.5)
    parser.add_argument("--pnp-confidence", type=float, default=0.999)
    parser.add_argument("--pnp-iterations", type=int, default=120)
    parser.add_argument("--min-pnp-inliers", type=int, default=18)
    parser.add_argument("--pose-solver", choices=["pnp", "stereo3d", "hybrid"], default="pnp")
    parser.add_argument("--stereo3d-threshold", type=float, default=0.12)
    parser.add_argument("--stereo3d-iterations", type=int, default=120)
    parser.add_argument("--min-stereo3d-inliers", type=int, default=18)
    parser.add_argument(
        "--pose-mode",
        choices=["relative", "map"],
        default="relative",
        help="relative uses frame-to-frame 3D points; map uses persistent stereo landmarks in the initial world frame.",
    )
    parser.add_argument("--max-step-m", type=float, default=0.20)
    parser.add_argument("--max-speed-mps", type=float, default=1.0)
    parser.add_argument("--max-rotation-rad", type=float, default=0.45)
    parser.add_argument("--imu-rotation-gate-rad", type=float, default=0.75)
    parser.add_argument("--translation-smoothing", type=float, default=0.15)
    parser.add_argument(
        "--coast-on-failure",
        action="store_true",
        help="When visual PnP fails, propagate a short constant-velocity step instead of freezing the pose.",
    )
    parser.add_argument("--coast-decay", type=float, default=0.85)
    parser.add_argument("--max-coast-frames", type=int, default=8)
    parser.add_argument(
        "--orientation-source",
        choices=["visual", "imu", "imu-yaw", "imu-step", "imu-yaw-step"],
        default="visual",
        help=(
            "visual keeps the original PnP rotation. imu propagates full rotation from gyro. "
            "imu-yaw propagates one gyro axis only and re-solves visual translation with that rotation fixed. "
            "imu-step/imu-yaw-step keep visual translation but use IMU attitude propagation."
        ),
    )
    parser.add_argument(
        "--imu-yaw-axis",
        choices=["x", "y", "z"],
        default="y",
        help="Gyro axis used by --orientation-source imu-yaw. Realsense optical yaw for a forward camera is often y.",
    )
    parser.add_argument(
        "--gyro-sign",
        type=float,
        default=1.0,
        help="Sign applied to gyro angular velocity before SO(3) integration; useful for frame convention checks.",
    )
    parser.add_argument("--disable-imu-rotation-gate", action="store_true")
    parser.add_argument("--write-debug-images", action="store_true")
    return parser.parse_args()


def run(args: argparse.Namespace) -> dict[str, Any]:
    dataset_dir = args.dataset_dir.expanduser().resolve()
    metadata = json.loads((dataset_dir / "metadata.json").read_text(encoding="utf-8"))
    times = read_times(dataset_dir / "times.txt")
    if args.max_frames > 0:
        times = times[: args.max_frames]
    if len(times) < 2:
        raise SystemExit("Need at least two stereo frames.")

    image0_dir = dataset_dir / "image_0"
    image1_dir = dataset_dir / "image_1"
    left_paths = [image0_dir / f"{index:06d}.png" for index in range(len(times))]
    right_paths = [image1_dir / f"{index:06d}.png" for index in range(len(times))]
    missing = [str(path) for path in left_paths + right_paths if not path.exists()]
    if missing:
        raise SystemExit(f"Missing exported stereo images. First missing: {missing[0]}")

    camera_matrix, fx, fy, cx, cy, baseline = camera_from_metadata(metadata)
    imu_rows = read_imu_csv(dataset_dir / "imu.csv")

    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    args.summary_json.parent.mkdir(parents=True, exist_ok=True)
    args.debug_csv.parent.mkdir(parents=True, exist_ok=True)

    prev_left = cv2.imread(str(left_paths[0]), cv2.IMREAD_GRAYSCALE)
    prev_right = cv2.imread(str(right_paths[0]), cv2.IMREAD_GRAYSCALE)
    if prev_left is None or prev_right is None:
        raise SystemExit("Failed to read first stereo frame.")

    next_track_id = 0
    initial_points = detect_grid_features(prev_left, [], args)
    points_3d, depth_mask, _ = estimate_stereo_depths(
        prev_left,
        prev_right,
        initial_points,
        fx,
        fy,
        cx,
        cy,
        baseline,
        args,
    )
    initial_left = initial_points[depth_mask]
    tracks: dict[int, Track] = {}
    for left_point, point_3d in zip(initial_left, points_3d):
        point_3d = point_3d.astype(np.float64)
        tracks[next_track_id] = Track(
            next_track_id,
            left_point.astype(np.float32),
            point_3d,
            world_point=point_3d.copy(),
        )
        next_track_id += 1

    position = np.zeros(3, dtype=np.float64)
    rotation_world_camera = np.eye(3, dtype=np.float64)
    previous_step = np.zeros(3, dtype=np.float64)
    rows = [
        PoseRow(
            frame_index=0,
            timestamp_sec=times[0],
            success=True,
            position=position.copy(),
            rotation=rotation_world_camera.copy(),
            pose_inliers=0,
            pose_inlier_ratio=0.0,
            active_tracks=len(tracks),
            stereo_tracks=len(tracks),
            note="initial_pose",
        )
    ]
    debug_rows: list[dict[str, Any]] = []
    accepted_count = 0
    coast_count = 0

    debug_dir = args.debug_csv.parent / "ros2_stereo_imu_debug_frames"
    if args.write_debug_images:
        debug_dir.mkdir(parents=True, exist_ok=True)

    for frame_index in range(1, len(times)):
        curr_left = cv2.imread(str(left_paths[frame_index]), cv2.IMREAD_GRAYSCALE)
        curr_right = cv2.imread(str(right_paths[frame_index]), cv2.IMREAD_GRAYSCALE)
        if curr_left is None or curr_right is None:
            break

        dt = max(times[frame_index] - times[frame_index - 1], 1e-6)
        track_ids = list(tracks.keys())
        prev_points = np.array([tracks[track_id].left_point for track_id in track_ids], dtype=np.float32)
        prev_velocities = np.array(
            [
                tracks[track_id].image_velocity if tracks[track_id].image_velocity is not None else np.zeros(2, dtype=np.float32)
                for track_id in track_ids
            ],
            dtype=np.float32,
        )
        flow = track_klt(prev_left, curr_left, prev_points, args, previous_velocities=prev_velocities)

        kept_ids = [track_id for track_id, keep in zip(track_ids, flow["mask"]) if keep]
        prev_kept_points = prev_points[flow["mask"]]
        curr_points = flow["curr"][flow["mask"]]
        if args.temporal_ransac != "none":
            temporal_mask = filter_temporal_matches(
                prev_kept_points,
                curr_points,
                camera_matrix,
                args,
            )
            kept_ids = [track_id for track_id, keep in zip(kept_ids, temporal_mask) if keep]
            curr_points = curr_points[temporal_mask]
        pnp_ids: list[int] = []
        pnp_image_points: list[np.ndarray] = []
        pnp_object_points: list[np.ndarray] = []
        for track_id, image_point in zip(kept_ids, curr_points):
            track = tracks[track_id]
            if track.age < args.min_track_age_for_pnp:
                continue
            object_point = track.world_point if args.pose_mode == "map" else track.point_3d
            if object_point is None:
                continue
            pnp_ids.append(track_id)
            pnp_image_points.append(image_point)
            pnp_object_points.append(object_point)
        object_points = np.array(pnp_object_points, dtype=np.float32)
        image_points = np.array(pnp_image_points, dtype=np.float32)
        stereo3d_ids: list[int] = []
        stereo3d_prev_points: list[np.ndarray] = []
        stereo3d_curr_points: list[np.ndarray] = []
        if args.pose_solver in {"stereo3d", "hybrid"} and args.pose_mode == "relative" and len(curr_points):
            current_points_3d, current_depth_mask, _ = estimate_stereo_depths(
                curr_left,
                curr_right,
                curr_points,
                fx,
                fy,
                cx,
                cy,
                baseline,
                args,
            )
            current_depth_ids = [track_id for track_id, keep in zip(kept_ids, current_depth_mask) if keep]
            for track_id, current_point_3d in zip(current_depth_ids, current_points_3d):
                track = tracks[track_id]
                if track.age < args.min_track_age_for_pnp:
                    continue
                stereo3d_ids.append(track_id)
                stereo3d_prev_points.append(track.point_3d)
                stereo3d_curr_points.append(current_point_3d)
        stereo3d_prev = np.array(stereo3d_prev_points, dtype=np.float64)
        stereo3d_curr = np.array(stereo3d_curr_points, dtype=np.float64)

        pose_success = False
        pnp_inliers = np.empty((0,), dtype=np.int32)
        pose_inlier_track_ids: set[int] = set()
        note = "not_enough_tracked_points"
        proposed_step = np.zeros(3, dtype=np.float64)
        relative_rotation = np.eye(3, dtype=np.float64)
        proposed_position = position.copy()
        proposed_rotation = rotation_world_camera.copy()
        imu_rotation = integrate_gyro_rotation(imu_rows, times[frame_index - 1], times[frame_index], args.gyro_sign)
        imu_yaw_rotation = integrate_gyro_rotation(
            imu_rows,
            times[frame_index - 1],
            times[frame_index],
            args.gyro_sign,
            axis=args.imu_yaw_axis,
        )
        imu_angle = rotation_angle(imu_rotation)
        visual_angle = 0.0

        if args.pose_solver in {"stereo3d", "hybrid"} and len(stereo3d_prev) >= max(6, args.min_stereo3d_inliers):
            stereo3d_result = solve_stereo3d_motion(stereo3d_prev, stereo3d_curr, args)
            if stereo3d_result is not None:
                relative_rotation, translation, stereo3d_inliers, _ = stereo3d_result
                pnp_inliers = stereo3d_inliers
                pose_inlier_track_ids = {
                    stereo3d_ids[int(index)]
                    for index in stereo3d_inliers.reshape(-1)
                    if int(index) < len(stereo3d_ids)
                }
                proposed_rotation = rotation_world_camera @ relative_rotation.T
                camera_step = -relative_rotation.T @ translation.reshape(3)
                proposed_step = rotation_world_camera @ camera_step
                proposed_position = position + proposed_step
                visual_angle = rotation_angle(relative_rotation)
                step_norm = float(np.linalg.norm(proposed_step))
                speed = step_norm / dt
                rotation_gate_ok = visual_angle <= args.max_rotation_rad
                imu_gate_ok = True
                if not args.disable_imu_rotation_gate:
                    imu_gate_ok = abs(visual_angle - imu_angle) <= args.imu_rotation_gate_rad
                motion_gate_ok = speed <= args.max_speed_mps or step_norm <= args.max_step_m

                if len(stereo3d_inliers) < args.min_stereo3d_inliers:
                    note = "stereo3d_low_inliers"
                elif not rotation_gate_ok:
                    note = "stereo3d_rotation_gate"
                elif not imu_gate_ok:
                    note = "stereo3d_imu_rotation_gate"
                elif not motion_gate_ok:
                    if step_norm > 1e-9:
                        limit = min(args.max_step_m, args.max_speed_mps * dt)
                        proposed_step = proposed_step * (limit / step_norm)
                        proposed_position = position + proposed_step
                        note = "stereo3d_motion_clamped"
                        pose_success = True
                    else:
                        note = "stereo3d_zero_step"
                else:
                    note = "stereo3d_accepted"
                    pose_success = True
            else:
                note = "stereo3d_failed"

        if not pose_success and args.pose_solver in {"pnp", "hybrid"} and len(object_points) >= max(6, args.min_pnp_inliers):
            pnp_result = solve_pnp_motion(object_points, image_points, camera_matrix, args)
            if pnp_result is not None:
                pnp_rotation, translation, pnp_inliers = pnp_result
                pose_inlier_track_ids = {
                    pnp_ids[int(index)]
                    for index in pnp_inliers.reshape(-1)
                    if int(index) < len(pnp_ids)
                }
                if args.pose_mode == "map":
                    proposed_rotation = pnp_rotation.T
                    proposed_position = -proposed_rotation @ translation.reshape(3)
                    relative_rotation = proposed_rotation.T @ rotation_world_camera
                    proposed_step = proposed_position - position
                else:
                    relative_rotation = pnp_rotation
                    camera_step_rotation = pnp_rotation
                    fixed_rotation = None
                    if args.orientation_source == "imu":
                        fixed_rotation = imu_rotation
                    elif args.orientation_source == "imu-yaw":
                        fixed_rotation = imu_yaw_rotation
                    elif args.orientation_source == "imu-step":
                        relative_rotation = imu_rotation
                    elif args.orientation_source == "imu-yaw-step":
                        relative_rotation = imu_yaw_rotation
                    if fixed_rotation is not None:
                        translation_from_imu = solve_translation_fixed_rotation(
                            object_points,
                            image_points,
                            camera_matrix,
                            fixed_rotation,
                            pnp_inliers,
                        )
                        if translation_from_imu is not None:
                            relative_rotation = fixed_rotation
                            camera_step_rotation = fixed_rotation
                            translation = translation_from_imu
                    proposed_rotation = rotation_world_camera @ relative_rotation.T
                    camera_step = -camera_step_rotation.T @ translation.reshape(3)
                    proposed_step = rotation_world_camera @ camera_step
                    proposed_position = position + proposed_step
                visual_angle = rotation_angle(relative_rotation)
                step_norm = float(np.linalg.norm(proposed_step))
                speed = step_norm / dt
                rotation_gate_ok = visual_angle <= args.max_rotation_rad
                imu_gate_ok = True
                if not args.disable_imu_rotation_gate:
                    imu_gate_ok = abs(visual_angle - imu_angle) <= args.imu_rotation_gate_rad
                motion_gate_ok = speed <= args.max_speed_mps or step_norm <= args.max_step_m

                if len(pnp_inliers) < args.min_pnp_inliers:
                    note = "pnp_low_inliers"
                elif not rotation_gate_ok:
                    note = "visual_rotation_gate"
                elif not imu_gate_ok:
                    note = "imu_rotation_gate"
                elif not motion_gate_ok:
                    if step_norm > 1e-9:
                        limit = min(args.max_step_m, args.max_speed_mps * dt)
                        proposed_step = proposed_step * (limit / step_norm)
                        proposed_position = position + proposed_step
                        note = "motion_clamped"
                        pose_success = True
                    else:
                        note = "zero_step"
                else:
                    note = "accepted"
                    pose_success = True
            else:
                note = "pnp_failed"

        if pose_success:
            if 0.0 < args.translation_smoothing < 1.0:
                proposed_step = (1.0 - args.translation_smoothing) * proposed_step + args.translation_smoothing * previous_step
                proposed_position = position + proposed_step
            position = proposed_position
            rotation_world_camera = proposed_rotation if args.pose_mode == "map" else rotation_world_camera @ relative_rotation.T
            previous_step = proposed_step
            accepted_count += 1
            coast_count = 0
        elif args.coast_on_failure and coast_count < args.max_coast_frames and float(np.linalg.norm(previous_step)) > 1e-9:
            decay = max(0.0, min(1.0, args.coast_decay))
            proposed_step = previous_step * decay
            position = position + proposed_step
            rotation_world_camera = rotation_world_camera @ imu_rotation.T
            previous_step = proposed_step
            coast_count += 1
            note = f"coasted_after_{note}"

        inlier_track_ids = set()
        if pose_inlier_track_ids:
            inlier_track_ids = pose_inlier_track_ids
        elif len(pnp_inliers):
            inlier_track_ids = {pnp_ids[int(index)] for index in pnp_inliers.reshape(-1) if int(index) < len(pnp_ids)}
        survivor_ids = [track_id for track_id in kept_ids if track_id in inlier_track_ids] if pose_success else kept_ids
        survivor_points = np.array(
            [point for track_id, point in zip(kept_ids, curr_points) if (track_id in inlier_track_ids if pose_success else True)],
            dtype=np.float32,
        )

        next_tracks: dict[int, Track] = {}
        stereo_count = 0
        if len(survivor_points):
            survivor_3d, survivor_depth_mask, depth_stats = estimate_stereo_depths(
                curr_left,
                curr_right,
                survivor_points,
                fx,
                fy,
                cx,
                cy,
                baseline,
                args,
            )
            depth_left = survivor_points[survivor_depth_mask]
            depth_ids = [track_id for track_id, keep in zip(survivor_ids, survivor_depth_mask) if keep]
            stereo_count = int(depth_stats["valid"])
            stereo_updates = {
                track_id: (left_point, point_3d)
                for track_id, left_point, point_3d in zip(depth_ids, depth_left, survivor_3d)
            }
            for track_id, left_point in zip(survivor_ids, survivor_points):
                previous = tracks[track_id]
                image_velocity = left_point.astype(np.float32) - previous.left_point.astype(np.float32)
                if track_id in stereo_updates:
                    left_point, point_3d = stereo_updates[track_id]
                    point_3d = point_3d.astype(np.float64)
                    world_point = position + rotation_world_camera @ point_3d
                elif args.pose_mode == "map" and previous.world_point is not None:
                    world_point = previous.world_point.copy()
                    point_3d = rotation_world_camera.T @ (world_point - position)
                else:
                    continue
                next_tracks[track_id] = Track(
                    track_id=track_id,
                    left_point=left_point.astype(np.float32),
                    point_3d=point_3d.astype(np.float64),
                    world_point=world_point.astype(np.float64),
                    image_velocity=image_velocity.astype(np.float32),
                    age=tracks[track_id].age + 1 if track_id in tracks else 1,
                )

        if len(next_tracks) < args.min_features:
            existing = [track.left_point for track in next_tracks.values()]
            new_left = detect_grid_features(curr_left, existing, args)
            if len(new_left):
                new_points_3d, new_depth_mask, _ = estimate_stereo_depths(
                    curr_left,
                    curr_right,
                    new_left,
                    fx,
                    fy,
                    cx,
                    cy,
                    baseline,
                    args,
                )
                for left_point, point_3d in zip(new_left[new_depth_mask], new_points_3d):
                    if len(next_tracks) >= args.max_features:
                        break
                    point_3d = point_3d.astype(np.float64)
                    next_tracks[next_track_id] = Track(
                        track_id=next_track_id,
                        left_point=left_point.astype(np.float32),
                        point_3d=point_3d,
                        world_point=(position + rotation_world_camera @ point_3d).astype(np.float64),
                    )
                    next_track_id += 1

        tracks = next_tracks
        rows.append(
            PoseRow(
                frame_index=frame_index,
                timestamp_sec=times[frame_index],
                success=pose_success,
                position=position.copy(),
                rotation=rotation_world_camera.copy(),
                pose_inliers=int(len(pnp_inliers)),
                pose_inlier_ratio=float(len(pnp_inliers) / max(1, len(object_points))),
                active_tracks=len(tracks),
                stereo_tracks=stereo_count,
                note=note,
            )
        )
        debug_rows.append(
            {
                "frame_index": frame_index,
                "timestamp_sec": f"{times[frame_index]:.9f}",
                "dt": f"{dt:.9f}",
                "tracked": len(kept_ids),
                "pnp_inliers": int(len(pnp_inliers)),
                "active_tracks": len(tracks),
                "stereo_tracks": stereo_count,
                "step_norm": f"{float(np.linalg.norm(proposed_step)):.9f}",
                "speed_mps": f"{float(np.linalg.norm(proposed_step)) / dt:.9f}",
                "visual_rotation_rad": f"{visual_angle:.9f}",
                "imu_rotation_rad": f"{imu_angle:.9f}",
                "note": note,
            }
        )

        if args.write_debug_images and frame_index % 10 == 0:
            write_debug_image(debug_dir / f"{frame_index:06d}.jpg", curr_left, tracks)

        prev_left = curr_left
        prev_right = curr_right

    write_odometry_csv(args.output_csv, rows)
    write_debug_csv(args.debug_csv, debug_rows)
    summary = make_summary(args, metadata, rows, debug_rows, accepted_count)
    args.summary_json.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


def read_times(path: Path) -> list[float]:
    return [float(line.strip()) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def read_imu_csv(path: Path) -> list[tuple[float, np.ndarray]]:
    rows: list[tuple[float, np.ndarray]] = []
    if not path.exists():
        return rows
    with path.open(newline="", encoding="utf-8") as csv_file:
        for row in csv.DictReader(csv_file):
            rows.append(
                (
                    float(row["timestamp_sec"]),
                    np.array([float(row["gx"]), float(row["gy"]), float(row["gz"])], dtype=np.float64),
                )
            )
    return rows


def camera_from_metadata(metadata: dict[str, Any]) -> tuple[np.ndarray, float, float, float, float, float]:
    cam0 = metadata["camera0"]
    k = cam0["k"]
    fx = float(k[0])
    fy = float(k[4])
    cx = float(k[2])
    cy = float(k[5])
    baseline = float(metadata.get("baseline_m") or 0.0)
    if baseline <= 0.0:
        p_right = metadata["camera1"]["p"]
        baseline = abs(float(p_right[3]) / fx)
    camera_matrix = np.array([[fx, 0.0, cx], [0.0, fy, cy], [0.0, 0.0, 1.0]], dtype=np.float64)
    return camera_matrix, fx, fy, cx, cy, baseline


def detect_grid_features(gray: np.ndarray, existing_points: list[np.ndarray], args: argparse.Namespace) -> np.ndarray:
    height, width = gray.shape
    mask = np.full((height, width), 255, dtype=np.uint8)
    for point in existing_points:
        x, y = point
        cv2.circle(mask, (int(round(x)), int(round(y))), args.min_distance, 0, thickness=-1)

    features: list[tuple[np.ndarray, float]] = []
    rows = max(1, args.grid_rows)
    cols = max(1, args.grid_cols)
    for row in range(rows):
        y0 = int(round(row * height / rows))
        y1 = int(round((row + 1) * height / rows))
        for col in range(cols):
            x0 = int(round(col * width / cols))
            x1 = int(round((col + 1) * width / cols))
            roi = gray[y0:y1, x0:x1]
            roi_mask = mask[y0:y1, x0:x1]
            if roi.size == 0:
                continue
            for point, response in detect_features_in_roi(roi, roi_mask, args):
                absolute = np.array([point[0] + x0, point[1] + y0], dtype=np.float32)
                if args.reject_repeated_patches and patch_is_repeated(gray, absolute, args):
                    continue
                features.append((absolute, response))

    if not features:
        return np.empty((0, 2), dtype=np.float32)
    features = sorted(
        features,
        key=lambda item: (
            int(item[0][1] // max(height / rows, 1)),
            int(item[0][0] // max(width / cols, 1)),
            -item[1],
        ),
    )
    return np.array([point for point, _ in features[: args.max_features]], dtype=np.float32)


def detect_features_in_roi(
    roi: np.ndarray,
    roi_mask: np.ndarray,
    args: argparse.Namespace,
) -> list[tuple[np.ndarray, float]]:
    if args.feature_detector in {"gftt", "harris"}:
        corners = cv2.goodFeaturesToTrack(
            roi,
            maxCorners=args.cell_max_features,
            qualityLevel=args.quality,
            minDistance=args.min_distance,
            mask=roi_mask,
            blockSize=args.block_size,
            useHarrisDetector=args.feature_detector == "harris",
        )
        if corners is None:
            return []
        if args.feature_detector == "harris":
            response_map = cv2.cornerHarris(roi, args.block_size, 3, 0.04)
        else:
            response_map = cv2.cornerMinEigenVal(roi, blockSize=args.block_size)
        points: list[tuple[np.ndarray, float]] = []
        height, width = roi.shape
        for corner in corners.reshape(-1, 2):
            x = int(np.clip(round(float(corner[0])), 0, width - 1))
            y = int(np.clip(round(float(corner[1])), 0, height - 1))
            points.append((corner.astype(np.float32), float(response_map[y, x])))
        return sorted(points, key=lambda item: item[1], reverse=True)[: args.cell_max_features]

    if args.feature_detector == "fast":
        detector = cv2.FastFeatureDetector_create(
            threshold=max(1, int(args.fast_threshold)),
            nonmaxSuppression=True,
        )
        keypoints = detector.detect(roi, roi_mask)
    elif args.feature_detector == "orb":
        detector = cv2.ORB_create(
            nfeatures=max(args.cell_max_features * 4, args.cell_max_features),
            fastThreshold=max(1, int(args.orb_fast_threshold)),
            edgeThreshold=max(8, int(args.patch_size)),
        )
        keypoints = detector.detect(roi, roi_mask)
    else:
        keypoints = []

    keypoints = sorted(keypoints, key=lambda kp: kp.response, reverse=True)
    return [
        (np.array(kp.pt, dtype=np.float32), float(kp.response))
        for kp in keypoints[: args.cell_max_features]
    ]


def patch_is_repeated(gray: np.ndarray, point: np.ndarray, args: argparse.Namespace) -> bool:
    patch_size = max(5, int(args.patch_size))
    if patch_size % 2 == 0:
        patch_size += 1
    radius = patch_size // 2
    x = int(round(float(point[0])))
    y = int(round(float(point[1])))
    height, width = gray.shape
    if x - radius < 0 or x + radius >= width or y - radius < 0 or y + radius >= height:
        return True

    patch = gray[y - radius : y + radius + 1, x - radius : x + radius + 1].astype(np.float32)
    patch -= float(np.mean(patch))
    patch_std = float(np.std(patch))
    if patch_std < args.patch_min_std:
        return True
    patch_norm = float(np.linalg.norm(patch))
    if patch_norm < 1e-9:
        return True

    search_radius = max(args.min_distance, int(args.patch_search_radius))
    stride = max(2, int(args.patch_search_stride))
    y0 = max(radius, y - search_radius)
    y1 = min(height - radius - 1, y + search_radius)
    x0 = max(radius, x - search_radius)
    x1 = min(width - radius - 1, x + search_radius)
    for yy in range(y0, y1 + 1, stride):
        for xx in range(x0, x1 + 1, stride):
            if abs(xx - x) <= args.min_distance and abs(yy - y) <= args.min_distance:
                continue
            other = gray[yy - radius : yy + radius + 1, xx - radius : xx + radius + 1].astype(np.float32)
            other -= float(np.mean(other))
            other_norm = float(np.linalg.norm(other))
            if other_norm < 1e-9:
                continue
            ncc = float(np.sum(patch * other) / (patch_norm * other_norm))
            if ncc >= args.patch_ncc_threshold:
                return True
    return False


def track_klt(
    prev_gray: np.ndarray,
    curr_gray: np.ndarray,
    prev_points: np.ndarray,
    args: argparse.Namespace,
    previous_velocities: np.ndarray | None = None,
) -> dict[str, np.ndarray]:
    if len(prev_points) == 0:
        return {
            "curr": np.empty((0, 2), dtype=np.float32),
            "mask": np.empty((0,), dtype=bool),
        }
    lk_kwargs = {
        "winSize": (args.klt_window, args.klt_window),
        "maxLevel": args.klt_levels,
        "criteria": (
            cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT,
            args.klt_iterations,
            args.klt_eps,
        ),
    }
    prev_in = prev_points.reshape(-1, 1, 2).astype(np.float32)
    initial_curr = None
    lk_flags = 0
    if args.klt_use_prediction and previous_velocities is not None and len(previous_velocities) == len(prev_points):
        initial_curr = (prev_points.reshape(-1, 2) + previous_velocities.reshape(-1, 2)).reshape(-1, 1, 2).astype(np.float32)
        lk_flags = cv2.OPTFLOW_USE_INITIAL_FLOW
    curr, status, err = cv2.calcOpticalFlowPyrLK(prev_gray, curr_gray, prev_in, initial_curr, flags=lk_flags, **lk_kwargs)
    if curr is None or status is None:
        return {"curr": np.empty((0, 2), dtype=np.float32), "mask": np.zeros(len(prev_points), dtype=bool)}
    back, back_status, back_err = cv2.calcOpticalFlowPyrLK(curr_gray, prev_gray, curr, None, **lk_kwargs)
    if back is None or back_status is None:
        return {"curr": curr.reshape(-1, 2), "mask": np.zeros(len(prev_points), dtype=bool)}
    curr2 = curr.reshape(-1, 2)
    back2 = back.reshape(-1, 2)
    status = status.reshape(-1).astype(bool)
    back_status = back_status.reshape(-1).astype(bool)
    fb = np.linalg.norm(prev_points.reshape(-1, 2) - back2, axis=1)
    finite = finite_points(curr2, curr_gray.shape)
    mask = status & back_status & finite & (fb <= args.fb_threshold)
    if args.klt_max_error > 0 and err is not None and back_err is not None:
        forward_error = err.reshape(-1)
        backward_error = back_err.reshape(-1)
        mask &= np.isfinite(forward_error) & np.isfinite(backward_error)
        mask &= (forward_error <= args.klt_max_error) & (backward_error <= args.klt_max_error)
    flow = np.linalg.norm(curr2 - prev_points.reshape(-1, 2), axis=1)
    if args.klt_max_flow_px > 0:
        mask &= flow <= args.klt_max_flow_px
    if args.klt_min_eigenvalue > 0:
        mask &= tracked_min_eigenvalue_mask(curr_gray, curr2, args)
    if args.klt_patch_ncc_threshold > 0:
        mask &= patch_ncc_mask(prev_gray, curr_gray, prev_points.reshape(-1, 2), curr2, args)
    if args.klt_local_flow_check:
        mask &= local_flow_consistency_mask(prev_points.reshape(-1, 2), curr2, mask, curr_gray.shape, args)
    if args.klt_velocity_check and previous_velocities is not None and len(previous_velocities) == len(prev_points):
        current_velocity = curr2 - prev_points.reshape(-1, 2)
        acceleration = np.linalg.norm(current_velocity - previous_velocities.reshape(-1, 2), axis=1)
        mask &= acceleration <= args.klt_max_accel_px
    return {"curr": curr2.astype(np.float32), "mask": mask}


def tracked_min_eigenvalue_mask(gray: np.ndarray, points: np.ndarray, args: argparse.Namespace) -> np.ndarray:
    response = cv2.cornerMinEigenVal(gray, blockSize=max(3, int(args.block_size)))
    height, width = gray.shape
    mask = np.zeros(len(points), dtype=bool)
    for index, point in enumerate(points):
        x = int(round(float(point[0])))
        y = int(round(float(point[1])))
        if 0 <= x < width and 0 <= y < height:
            mask[index] = float(response[y, x]) >= args.klt_min_eigenvalue
    return mask


def patch_ncc_mask(prev_gray: np.ndarray, curr_gray: np.ndarray, prev_points: np.ndarray, curr_points: np.ndarray, args: argparse.Namespace) -> np.ndarray:
    patch_size = max(5, int(args.klt_patch_size))
    if patch_size % 2 == 0:
        patch_size += 1
    radius = patch_size // 2
    mask = np.zeros(len(curr_points), dtype=bool)
    for index, (prev_point, curr_point) in enumerate(zip(prev_points, curr_points)):
        prev_patch = extract_patch(prev_gray, prev_point, radius)
        curr_patch = extract_patch(curr_gray, curr_point, radius)
        if prev_patch is None or curr_patch is None:
            continue
        prev_patch -= float(np.mean(prev_patch))
        curr_patch -= float(np.mean(curr_patch))
        denom = float(np.linalg.norm(prev_patch) * np.linalg.norm(curr_patch))
        if denom < 1e-9:
            continue
        mask[index] = float(np.sum(prev_patch * curr_patch) / denom) >= args.klt_patch_ncc_threshold
    return mask


def extract_patch(gray: np.ndarray, point: np.ndarray, radius: int) -> np.ndarray | None:
    x = int(round(float(point[0])))
    y = int(round(float(point[1])))
    height, width = gray.shape
    if x - radius < 0 or x + radius >= width or y - radius < 0 or y + radius >= height:
        return None
    return gray[y - radius : y + radius + 1, x - radius : x + radius + 1].astype(np.float32)


def local_flow_consistency_mask(
    prev_points: np.ndarray,
    curr_points: np.ndarray,
    base_mask: np.ndarray,
    shape: tuple[int, int],
    args: argparse.Namespace,
) -> np.ndarray:
    height, width = shape
    rows = max(1, int(args.grid_rows))
    cols = max(1, int(args.grid_cols))
    flow = curr_points - prev_points
    keep = base_mask.copy()
    for row in range(rows):
        y0 = row * height / rows
        y1 = (row + 1) * height / rows
        for col in range(cols):
            x0 = col * width / cols
            x1 = (col + 1) * width / cols
            cell = (
                base_mask
                & (prev_points[:, 0] >= x0)
                & (prev_points[:, 0] < x1)
                & (prev_points[:, 1] >= y0)
                & (prev_points[:, 1] < y1)
            )
            indices = np.flatnonzero(cell)
            if len(indices) < args.klt_local_flow_min_points:
                continue
            cell_flow = flow[indices]
            median_flow = np.median(cell_flow, axis=0)
            residual = np.linalg.norm(cell_flow - median_flow, axis=1)
            median_residual = float(np.median(residual))
            mad = float(np.median(np.abs(residual - median_residual)))
            threshold = max(args.klt_local_flow_min_abs, args.klt_local_flow_mad_factor * 1.4826 * mad)
            keep[indices] &= residual <= threshold
    return keep


def filter_temporal_matches(
    prev_points: np.ndarray,
    curr_points: np.ndarray,
    camera_matrix: np.ndarray,
    args: argparse.Namespace,
) -> np.ndarray:
    if len(prev_points) < 8 or len(curr_points) < 8:
        return np.ones(len(curr_points), dtype=bool)
    try:
        if args.temporal_ransac == "essential":
            _, inlier_mask = cv2.findEssentialMat(
                prev_points.astype(np.float32),
                curr_points.astype(np.float32),
                camera_matrix,
                method=cv2.RANSAC,
                prob=args.temporal_ransac_confidence,
                threshold=args.temporal_ransac_threshold,
            )
        elif args.temporal_ransac == "fundamental":
            _, inlier_mask = cv2.findFundamentalMat(
                prev_points.astype(np.float32),
                curr_points.astype(np.float32),
                method=cv2.FM_RANSAC,
                ransacReprojThreshold=args.temporal_ransac_threshold,
                confidence=args.temporal_ransac_confidence,
            )
        else:
            return np.ones(len(curr_points), dtype=bool)
    except cv2.error:
        return np.ones(len(curr_points), dtype=bool)
    if inlier_mask is None:
        return np.ones(len(curr_points), dtype=bool)
    mask = inlier_mask.reshape(-1).astype(bool)
    if len(mask) != len(curr_points) or int(np.count_nonzero(mask)) < args.min_temporal_inliers:
        return np.ones(len(curr_points), dtype=bool)
    return mask


def match_stereo(left_gray: np.ndarray, right_gray: np.ndarray, left_points: np.ndarray, args: argparse.Namespace) -> tuple[np.ndarray, np.ndarray]:
    if len(left_points) == 0:
        return np.empty((0, 2), dtype=np.float32), np.empty((0,), dtype=bool)
    lk_kwargs = {
        "winSize": (args.klt_window, args.klt_window),
        "maxLevel": args.klt_levels,
        "criteria": (
            cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT,
            args.klt_iterations,
            args.klt_eps,
        ),
    }
    left_in = left_points.reshape(-1, 1, 2).astype(np.float32)
    right, status, err = cv2.calcOpticalFlowPyrLK(left_gray, right_gray, left_in, None, **lk_kwargs)
    if right is None or status is None:
        return np.empty((0, 2), dtype=np.float32), np.zeros(len(left_points), dtype=bool)
    back, back_status, back_err = cv2.calcOpticalFlowPyrLK(right_gray, left_gray, right, None, **lk_kwargs)
    if back is None or back_status is None:
        return right.reshape(-1, 2), np.zeros(len(left_points), dtype=bool)

    right2 = right.reshape(-1, 2).astype(np.float32)
    back2 = back.reshape(-1, 2).astype(np.float32)
    status = status.reshape(-1).astype(bool)
    back_status = back_status.reshape(-1).astype(bool)
    fb = np.linalg.norm(left_points.reshape(-1, 2) - back2, axis=1)
    disparity = left_points[:, 0] - right2[:, 0]
    epi = np.abs(left_points[:, 1] - right2[:, 1])
    finite = finite_points(right2, right_gray.shape)
    mask = (
        status
        & back_status
        & finite
        & (fb <= args.stereo_fb_threshold)
        & (epi <= args.epipolar_threshold)
        & (disparity >= args.min_disparity)
        & (disparity <= args.max_disparity)
    )
    if args.stereo_max_error > 0 and err is not None and back_err is not None:
        forward_error = err.reshape(-1)
        backward_error = back_err.reshape(-1)
        mask &= np.isfinite(forward_error) & np.isfinite(backward_error)
        mask &= (forward_error <= args.stereo_max_error) & (backward_error <= args.stereo_max_error)
    if args.stereo_disparity_consistency:
        mask &= disparity_consistency_mask(left_points.reshape(-1, 2), disparity, mask, left_gray.shape, args)
    return right2, mask


def disparity_consistency_mask(
    left_points: np.ndarray,
    disparity: np.ndarray,
    base_mask: np.ndarray,
    shape: tuple[int, int],
    args: argparse.Namespace,
) -> np.ndarray:
    height, width = shape
    rows = max(1, int(args.grid_rows))
    cols = max(1, int(args.grid_cols))
    keep = base_mask.copy()
    for row in range(rows):
        y0 = row * height / rows
        y1 = (row + 1) * height / rows
        for col in range(cols):
            x0 = col * width / cols
            x1 = (col + 1) * width / cols
            cell = (
                base_mask
                & (left_points[:, 0] >= x0)
                & (left_points[:, 0] < x1)
                & (left_points[:, 1] >= y0)
                & (left_points[:, 1] < y1)
            )
            indices = np.flatnonzero(cell)
            if len(indices) < args.stereo_disparity_min_points:
                continue
            values = disparity[indices]
            median = float(np.median(values))
            residual = np.abs(values - median)
            mad = float(np.median(np.abs(residual - np.median(residual))))
            threshold = max(args.stereo_disparity_min_abs, args.stereo_disparity_mad_factor * 1.4826 * mad)
            keep[indices] &= residual <= threshold
    return keep


def triangulate_rectified(
    left_points: np.ndarray,
    right_points: np.ndarray,
    fx: float,
    fy: float,
    cx: float,
    cy: float,
    baseline: float,
    args: argparse.Namespace,
) -> tuple[np.ndarray, np.ndarray]:
    if len(left_points) == 0:
        return np.empty((0, 3), dtype=np.float64), np.empty((0,), dtype=bool)
    disparity = left_points[:, 0] - right_points[:, 0]
    z = fx * baseline / np.maximum(disparity, 1e-9)
    x = (left_points[:, 0] - cx) * z / fx
    y = (left_points[:, 1] - cy) * z / fy
    points = np.column_stack([x, y, z]).astype(np.float64)
    points *= args.depth_scale
    mask = (
        np.isfinite(points).all(axis=1)
        & (points[:, 2] >= args.min_depth)
        & (points[:, 2] <= args.max_depth)
    )
    return points[mask], mask


def estimate_stereo_depths(
    left_gray: np.ndarray,
    right_gray: np.ndarray,
    left_points: np.ndarray,
    fx: float,
    fy: float,
    cx: float,
    cy: float,
    baseline: float,
    args: argparse.Namespace,
) -> tuple[np.ndarray, np.ndarray, dict[str, int]]:
    if len(left_points) == 0:
        return np.empty((0, 3), dtype=np.float64), np.empty((0,), dtype=bool), {"valid": 0, "klt": 0, "sgbm": 0}

    points_3d = np.zeros((len(left_points), 3), dtype=np.float64)
    valid = np.zeros(len(left_points), dtype=bool)
    klt_count = 0
    sgbm_count = 0

    if args.stereo_depth_mode in {"klt", "hybrid"}:
        right_points, stereo_mask = match_stereo(left_gray, right_gray, left_points, args)
        stereo_indices = np.flatnonzero(stereo_mask)
        if len(stereo_indices):
            klt_points_3d, depth_mask = triangulate_rectified(
                left_points[stereo_indices],
                right_points[stereo_indices],
                fx,
                fy,
                cx,
                cy,
                baseline,
                args,
            )
            valid_indices = stereo_indices[depth_mask]
            points_3d[valid_indices] = klt_points_3d
            valid[valid_indices] = True
            klt_count = len(valid_indices)

    use_sgbm = args.stereo_depth_mode == "sgbm" or (
        args.stereo_depth_mode == "hybrid" and klt_count < args.sgbm_fallback_min_klt
    )
    if use_sgbm:
        missing_indices = np.flatnonzero(~valid) if args.stereo_depth_mode == "hybrid" else np.arange(len(left_points))
        if len(missing_indices):
            disparity = compute_sgbm_disparity(left_gray, right_gray, args)
            sgbm_points_3d, sgbm_mask = triangulate_from_disparity_map(
                left_points[missing_indices],
                disparity,
                fx,
                fy,
                cx,
                cy,
                baseline,
                args,
            )
            valid_indices = missing_indices[sgbm_mask]
            points_3d[valid_indices] = sgbm_points_3d
            valid[valid_indices] = True
            sgbm_count = len(valid_indices)

    return points_3d[valid], valid, {"valid": int(np.sum(valid)), "klt": klt_count, "sgbm": sgbm_count}


def compute_sgbm_disparity(left_gray: np.ndarray, right_gray: np.ndarray, args: argparse.Namespace) -> np.ndarray:
    num_disparities = max(16, int(math.ceil(args.sgbm_num_disparities / 16.0) * 16))
    block_size = int(args.sgbm_block_size)
    if block_size % 2 == 0:
        block_size += 1
    block_size = max(3, block_size)
    matcher = cv2.StereoSGBM_create(
        minDisparity=0,
        numDisparities=num_disparities,
        blockSize=block_size,
        P1=8 * block_size * block_size,
        P2=32 * block_size * block_size,
        disp12MaxDiff=2,
        uniquenessRatio=args.sgbm_uniqueness,
        speckleWindowSize=50,
        speckleRange=2,
        mode=cv2.STEREO_SGBM_MODE_SGBM_3WAY,
    )
    return matcher.compute(left_gray, right_gray).astype(np.float32) / 16.0


def triangulate_from_disparity_map(
    left_points: np.ndarray,
    disparity: np.ndarray,
    fx: float,
    fy: float,
    cx: float,
    cy: float,
    baseline: float,
    args: argparse.Namespace,
) -> tuple[np.ndarray, np.ndarray]:
    if len(left_points) == 0:
        return np.empty((0, 3), dtype=np.float64), np.empty((0,), dtype=bool)
    points: list[np.ndarray] = []
    valid: list[bool] = []
    radius = max(0, int(args.sgbm_sample_radius))
    height, width = disparity.shape
    for point in left_points:
        x, y = point
        xi = int(round(float(x)))
        yi = int(round(float(y)))
        if xi < 0 or xi >= width or yi < 0 or yi >= height:
            valid.append(False)
            continue
        x0 = max(0, xi - radius)
        x1 = min(width, xi + radius + 1)
        y0 = max(0, yi - radius)
        y1 = min(height, yi + radius + 1)
        patch = disparity[y0:y1, x0:x1]
        good = patch[
            np.isfinite(patch)
            & (patch >= args.min_disparity)
            & (patch <= args.max_disparity)
        ]
        if len(good) == 0:
            valid.append(False)
            continue
        disp = float(np.median(good))
        z = fx * baseline / max(disp, 1e-9)
        if z < args.min_depth or z > args.max_depth:
            valid.append(False)
            continue
        points.append(np.array([(x - cx) * z / fx, (y - cy) * z / fy, z], dtype=np.float64) * args.depth_scale)
        valid.append(True)
    return np.array(points, dtype=np.float64), np.array(valid, dtype=bool)


def solve_stereo3d_motion(
    previous_points: np.ndarray,
    current_points: np.ndarray,
    args: argparse.Namespace,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, float] | None:
    if len(previous_points) < max(6, args.min_stereo3d_inliers) or len(current_points) != len(previous_points):
        return None
    valid = np.isfinite(previous_points).all(axis=1) & np.isfinite(current_points).all(axis=1)
    indices = np.flatnonzero(valid)
    if len(indices) < max(6, args.min_stereo3d_inliers):
        return None
    prev = previous_points[indices].astype(np.float64)
    curr = current_points[indices].astype(np.float64)
    rng = np.random.default_rng(7)
    best_local_inliers: np.ndarray | None = None
    best_rmse = float("inf")
    sample_size = 3
    iterations = max(1, int(args.stereo3d_iterations))
    threshold = max(1e-6, float(args.stereo3d_threshold))

    for _ in range(iterations):
        if len(prev) < sample_size:
            break
        sample = rng.choice(len(prev), size=sample_size, replace=False)
        candidate = estimate_rigid_transform(prev[sample], curr[sample])
        if candidate is None:
            continue
        rotation, translation = candidate
        residual = np.linalg.norm((rotation @ prev.T).T + translation - curr, axis=1)
        local_inliers = np.flatnonzero(residual <= threshold)
        if len(local_inliers) < args.min_stereo3d_inliers:
            continue
        rmse = float(math.sqrt(np.mean(residual[local_inliers] ** 2)))
        if best_local_inliers is None or len(local_inliers) > len(best_local_inliers) or (
            len(local_inliers) == len(best_local_inliers) and rmse < best_rmse
        ):
            best_local_inliers = local_inliers
            best_rmse = rmse

    if best_local_inliers is None or len(best_local_inliers) < args.min_stereo3d_inliers:
        return None
    refined = estimate_rigid_transform(prev[best_local_inliers], curr[best_local_inliers])
    if refined is None:
        return None
    rotation, translation = refined
    residual = np.linalg.norm((rotation @ prev.T).T + translation - curr, axis=1)
    local_inliers = np.flatnonzero(residual <= threshold)
    if len(local_inliers) < args.min_stereo3d_inliers:
        return None
    rmse = float(math.sqrt(np.mean(residual[local_inliers] ** 2)))
    return rotation.astype(np.float64), translation.astype(np.float64), indices[local_inliers].astype(np.int32), rmse


def estimate_rigid_transform(source: np.ndarray, target: np.ndarray) -> tuple[np.ndarray, np.ndarray] | None:
    if len(source) < 3 or len(target) != len(source):
        return None
    source_centroid = np.mean(source, axis=0)
    target_centroid = np.mean(target, axis=0)
    source_centered = source - source_centroid
    target_centered = target - target_centroid
    if np.linalg.matrix_rank(source_centered) < 2:
        return None
    covariance = source_centered.T @ target_centered
    try:
        u, _, vt = np.linalg.svd(covariance)
    except np.linalg.LinAlgError:
        return None
    rotation = vt.T @ u.T
    if np.linalg.det(rotation) < 0:
        vt[-1, :] *= -1.0
        rotation = vt.T @ u.T
    translation = target_centroid - rotation @ source_centroid
    if not np.isfinite(rotation).all() or not np.isfinite(translation).all():
        return None
    return rotation, translation


def solve_pnp_motion(
    object_points: np.ndarray,
    image_points: np.ndarray,
    camera_matrix: np.ndarray,
    args: argparse.Namespace,
) -> tuple[np.ndarray, np.ndarray, np.ndarray] | None:
    try:
        ok, rvec, tvec, inliers = cv2.solvePnPRansac(
            object_points.astype(np.float32),
            image_points.astype(np.float32),
            camera_matrix,
            None,
            iterationsCount=args.pnp_iterations,
            reprojectionError=args.pnp_threshold,
            confidence=args.pnp_confidence,
            flags=cv2.SOLVEPNP_ITERATIVE,
        )
    except cv2.error:
        return None
    if not ok or rvec is None or tvec is None or inliers is None:
        return None
    rotation, _ = cv2.Rodrigues(rvec)
    return rotation.astype(np.float64), tvec.reshape(3).astype(np.float64), inliers.reshape(-1)


def solve_translation_fixed_rotation(
    object_points: np.ndarray,
    image_points: np.ndarray,
    camera_matrix: np.ndarray,
    rotation: np.ndarray,
    inliers: np.ndarray,
) -> np.ndarray | None:
    if len(object_points) < 6:
        return None
    indices = inliers.reshape(-1).astype(int) if len(inliers) else np.arange(len(object_points))
    indices = indices[(indices >= 0) & (indices < len(object_points))]
    if len(indices) < 6:
        return None

    fx = float(camera_matrix[0, 0])
    fy = float(camera_matrix[1, 1])
    cx = float(camera_matrix[0, 2])
    cy = float(camera_matrix[1, 2])
    rows = []
    rhs = []
    for index in indices:
        u, v = image_points[index]
        bearing = np.array([(float(u) - cx) / fx, (float(v) - cy) / fy, 1.0], dtype=np.float64)
        skew = np.array(
            [
                [0.0, -bearing[2], bearing[1]],
                [bearing[2], 0.0, -bearing[0]],
                [-bearing[1], bearing[0], 0.0],
            ],
            dtype=np.float64,
        )
        rotated_point = rotation @ object_points[index].astype(np.float64)
        rows.append(skew[:2])
        rhs.append((-skew @ rotated_point)[:2])
    matrix = np.vstack(rows)
    target = np.concatenate(rhs)
    try:
        translation, _, _, _ = np.linalg.lstsq(matrix, target, rcond=None)
    except np.linalg.LinAlgError:
        return None
    if not np.isfinite(translation).all():
        return None
    return translation.astype(np.float64)


def integrate_gyro_rotation(
    imu_rows: list[tuple[float, np.ndarray]],
    start: float,
    end: float,
    gyro_sign: float = 1.0,
    axis: str | None = None,
) -> np.ndarray:
    if end <= start or not imu_rows:
        return np.eye(3, dtype=np.float64)
    selected = [(t, w) for t, w in imu_rows if start <= t <= end]
    if len(selected) < 2:
        return np.eye(3, dtype=np.float64)
    rotation = np.eye(3, dtype=np.float64)
    for (t0, w0), (t1, w1) in zip(selected, selected[1:]):
        dt = max(t1 - t0, 0.0)
        omega = gyro_sign * 0.5 * (w0 + w1)
        if axis is not None:
            axis_index = {"x": 0, "y": 1, "z": 2}[axis]
            masked = np.zeros(3, dtype=np.float64)
            masked[axis_index] = omega[axis_index]
            omega = masked
        rotation = rotation @ exp_so3(omega * dt)
    return rotation


def exp_so3(vec: np.ndarray) -> np.ndarray:
    theta = float(np.linalg.norm(vec))
    if theta < 1e-12:
        return np.eye(3, dtype=np.float64)
    axis = vec / theta
    skew = np.array(
        [
            [0.0, -axis[2], axis[1]],
            [axis[2], 0.0, -axis[0]],
            [-axis[1], axis[0], 0.0],
        ],
        dtype=np.float64,
    )
    return np.eye(3, dtype=np.float64) + math.sin(theta) * skew + (1.0 - math.cos(theta)) * (skew @ skew)


def rotation_angle(rotation: np.ndarray) -> float:
    value = (float(np.trace(rotation)) - 1.0) * 0.5
    return math.acos(max(-1.0, min(1.0, value)))


def finite_points(points: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    height, width = shape
    return (
        np.isfinite(points).all(axis=1)
        & (points[:, 0] >= 0)
        & (points[:, 0] < width)
        & (points[:, 1] >= 0)
        & (points[:, 1] < height)
    )


def write_odometry_csv(path: Path, rows: list[PoseRow]) -> None:
    with path.open("w", newline="", encoding="utf-8") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(
            [
                "frame_index",
                "timestamp_sec",
                "x",
                "y",
                "z",
                "qx",
                "qy",
                "qz",
                "qw",
                "pose_success",
                "pose_inliers",
                "pose_inlier_ratio",
                "active_tracks",
                "stereo_tracks",
                "scale_mode",
                "note",
            ]
        )
        for row in rows:
            qx, qy, qz, qw = rotation_to_quaternion(row.rotation)
            writer.writerow(
                [
                    row.frame_index,
                    f"{row.timestamp_sec:.9f}",
                    f"{row.position[0]:.9f}",
                    f"{row.position[1]:.9f}",
                    f"{row.position[2]:.9f}",
                    f"{qx:.9f}",
                    f"{qy:.9f}",
                    f"{qz:.9f}",
                    f"{qw:.9f}",
                    "1" if row.success else "0",
                    row.pose_inliers,
                    f"{row.pose_inlier_ratio:.6f}",
                    row.active_tracks,
                    row.stereo_tracks,
                    "metric_stereo_pnp_imu_gated",
                    row.note,
                ]
            )


def write_debug_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def make_summary(
    args: argparse.Namespace,
    metadata: dict[str, Any],
    rows: list[PoseRow],
    debug_rows: list[dict[str, Any]],
    accepted_count: int,
) -> dict[str, Any]:
    path_length = 0.0
    max_step = 0.0
    max_speed = 0.0
    for prev, cur in zip(rows, rows[1:]):
        dt = max(cur.timestamp_sec - prev.timestamp_sec, 1e-6)
        step = float(np.linalg.norm(cur.position - prev.position))
        path_length += step
        max_step = max(max_step, step)
        max_speed = max(max_speed, step / dt)
    active = [row.active_tracks for row in rows]
    inliers = [int(row.get("pnp_inliers", 0)) for row in debug_rows]
    notes: dict[str, int] = {}
    for row in rows:
        notes[row.note] = notes.get(row.note, 0) + 1
    return {
        "mode": "ros2_native_stereo_imu_vio",
        "estimator_inputs": ["stereo_left", "stereo_right", "imu"],
        "reference_inputs_used": [],
        "dvl_usage": "not_used_in_estimator_reference_only",
        "dataset_dir": str(args.dataset_dir),
        "output_csv": str(args.output_csv),
        "summary_json": str(args.summary_json),
        "debug_csv": str(args.debug_csv),
        "metadata": {
            "frames": len(rows),
            "fps": metadata.get("fps"),
            "duration_sec": rows[-1].timestamp_sec - rows[0].timestamp_sec if len(rows) > 1 else 0.0,
            "width": metadata.get("width"),
            "height": metadata.get("height"),
            "start_frame": metadata.get("start_frame", 0),
            "stride": metadata.get("stride", 1),
            "baseline_m": metadata.get("baseline_m"),
            "imu_source": metadata.get("imu_source"),
            "imu_samples": metadata.get("imu_samples"),
        },
        "pose_count": len(rows),
        "pose_success_count": accepted_count,
        "pose_success_ratio": accepted_count / max(1, len(rows) - 1),
        "trajectory_stats": {
            "rows": float(len(rows)),
            "duration_sec": rows[-1].timestamp_sec - rows[0].timestamp_sec if len(rows) > 1 else 0.0,
            "path_length_m": path_length,
            "max_step_m": max_step,
            "max_speed_mps": max_speed,
            "span_x_m": float(max(row.position[0] for row in rows) - min(row.position[0] for row in rows)),
            "span_y_m": float(max(row.position[1] for row in rows) - min(row.position[1] for row in rows)),
            "span_z_m": float(max(row.position[2] for row in rows) - min(row.position[2] for row in rows)),
        },
        "tracking_stats": {
            "mean_active_tracks": statistics.fmean(active) if active else 0.0,
            "median_active_tracks": statistics.median(active) if active else 0.0,
            "mean_pnp_inliers": statistics.fmean(inliers) if inliers else 0.0,
        },
        "note_counts": notes,
        "parameters": {
            "feature_detector": args.feature_detector,
            "max_features": args.max_features,
            "min_features": args.min_features,
            "quality": args.quality,
            "min_distance": args.min_distance,
            "fast_threshold": args.fast_threshold,
            "orb_fast_threshold": args.orb_fast_threshold,
            "reject_repeated_patches": args.reject_repeated_patches,
            "patch_size": args.patch_size,
            "patch_search_radius": args.patch_search_radius,
            "patch_ncc_threshold": args.patch_ncc_threshold,
            "grid": [args.grid_rows, args.grid_cols],
            "fb_threshold": args.fb_threshold,
            "klt_max_error": args.klt_max_error,
            "klt_max_flow_px": args.klt_max_flow_px,
            "klt_min_eigenvalue": args.klt_min_eigenvalue,
            "klt_patch_size": args.klt_patch_size,
            "klt_patch_ncc_threshold": args.klt_patch_ncc_threshold,
            "klt_local_flow_check": args.klt_local_flow_check,
            "klt_local_flow_mad_factor": args.klt_local_flow_mad_factor,
            "klt_use_prediction": args.klt_use_prediction,
            "klt_velocity_check": args.klt_velocity_check,
            "klt_max_accel_px": args.klt_max_accel_px,
            "min_track_age_for_pnp": args.min_track_age_for_pnp,
            "temporal_ransac": args.temporal_ransac,
            "temporal_ransac_threshold": args.temporal_ransac_threshold,
            "min_temporal_inliers": args.min_temporal_inliers,
            "stereo_fb_threshold": args.stereo_fb_threshold,
            "stereo_max_error": args.stereo_max_error,
            "epipolar_threshold": args.epipolar_threshold,
            "stereo_disparity_consistency": args.stereo_disparity_consistency,
            "stereo_disparity_mad_factor": args.stereo_disparity_mad_factor,
            "stereo_disparity_min_abs": args.stereo_disparity_min_abs,
            "pnp_threshold": args.pnp_threshold,
            "min_pnp_inliers": args.min_pnp_inliers,
            "pose_solver": args.pose_solver,
            "stereo3d_threshold": args.stereo3d_threshold,
            "stereo3d_iterations": args.stereo3d_iterations,
            "min_stereo3d_inliers": args.min_stereo3d_inliers,
            "pose_mode": args.pose_mode,
            "stereo_depth_mode": args.stereo_depth_mode,
            "depth_scale": args.depth_scale,
            "max_step_m": args.max_step_m,
            "max_speed_mps": args.max_speed_mps,
            "max_rotation_rad": args.max_rotation_rad,
            "imu_rotation_gate_rad": args.imu_rotation_gate_rad,
            "orientation_source": args.orientation_source,
            "gyro_sign": args.gyro_sign,
            "imu_yaw_axis": args.imu_yaw_axis,
            "translation_smoothing": args.translation_smoothing,
            "coast_on_failure": args.coast_on_failure,
            "coast_decay": args.coast_decay,
            "max_coast_frames": args.max_coast_frames,
            "imu_rotation_gate_enabled": not args.disable_imu_rotation_gate,
        },
    }


def write_debug_image(path: Path, gray: np.ndarray, tracks: dict[int, Track]) -> None:
    image = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    for track in tracks.values():
        x, y = track.left_point
        cv2.circle(image, (int(round(x)), int(round(y))), 2, (0, 255, 0), -1)
    cv2.imwrite(str(path), image)


def rotation_to_quaternion(rotation: np.ndarray) -> tuple[float, float, float, float]:
    trace = float(np.trace(rotation))
    if trace > 0.0:
        scale = math.sqrt(trace + 1.0) * 2.0
        qw = 0.25 * scale
        qx = (rotation[2, 1] - rotation[1, 2]) / scale
        qy = (rotation[0, 2] - rotation[2, 0]) / scale
        qz = (rotation[1, 0] - rotation[0, 1]) / scale
    else:
        diagonal = np.diag(rotation)
        index = int(np.argmax(diagonal))
        if index == 0:
            scale = math.sqrt(1.0 + rotation[0, 0] - rotation[1, 1] - rotation[2, 2]) * 2.0
            qw = (rotation[2, 1] - rotation[1, 2]) / scale
            qx = 0.25 * scale
            qy = (rotation[0, 1] + rotation[1, 0]) / scale
            qz = (rotation[0, 2] + rotation[2, 0]) / scale
        elif index == 1:
            scale = math.sqrt(1.0 + rotation[1, 1] - rotation[0, 0] - rotation[2, 2]) * 2.0
            qw = (rotation[0, 2] - rotation[2, 0]) / scale
            qx = (rotation[0, 1] + rotation[1, 0]) / scale
            qy = 0.25 * scale
            qz = (rotation[1, 2] + rotation[2, 1]) / scale
        else:
            scale = math.sqrt(1.0 + rotation[2, 2] - rotation[0, 0] - rotation[1, 1]) * 2.0
            qw = (rotation[1, 0] - rotation[0, 1]) / scale
            qx = (rotation[0, 2] + rotation[2, 0]) / scale
            qy = (rotation[1, 2] + rotation[2, 1]) / scale
            qz = 0.25 * scale
    quaternion = np.array([qx, qy, qz, qw], dtype=np.float64)
    norm = float(np.linalg.norm(quaternion))
    if norm == 0.0:
        return (0.0, 0.0, 0.0, 1.0)
    return tuple((quaternion / norm).tolist())


if __name__ == "__main__":
    main()
