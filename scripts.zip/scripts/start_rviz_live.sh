#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

# Conda's ROS activation script reads CONDA_BUILD even when it is unset.
# Keep strict mode for the script, but relax nounset while conda activates.
set +u
source /Users/kanghyunmin/miniconda3/bin/activate ros2_h311
set -u

if pgrep -fl "ros2_publish_odometry.py" >/dev/null 2>&1; then
  pkill -f "ros2_publish_odometry.py" || true
fi

python scripts/ros2_publish_odometry.py \
  --csv outputs/live/latest_odometry.csv \
  --rate "${RVIZ_ODOM_RATE:-60}" \
  --loop \
  --coordinate-frame ros \
  --watch &

exec rviz2 -d rviz/vio_frontend.rviz
