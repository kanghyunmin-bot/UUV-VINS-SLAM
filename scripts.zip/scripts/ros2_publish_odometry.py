#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import rclpy
from geometry_msgs.msg import PoseStamped, TransformStamped
from nav_msgs.msg import Odometry, Path as RosPath
from rclpy.node import Node
from tf2_ros import TransformBroadcaster


class OdometryCsvPublisher(Node):
    def __init__(self, args: argparse.Namespace) -> None:
        super().__init__("vio_frontend_odometry_csv_publisher")
        self.csv_path = args.csv
        self.watch = args.watch
        self.last_mtime_ns = 0
        self.index = 0
        self.loop = args.loop
        self.frame_id = args.frame_id
        self.child_frame_id = args.child_frame_id
        self.coordinate_frame = args.coordinate_frame
        self.success_only_path = args.success_only_path
        self.rows = []

        self.odom_pub = self.create_publisher(Odometry, args.odom_topic, 10)
        self.path_pub = self.create_publisher(RosPath, args.path_topic, 10)
        self.tf_broadcaster = TransformBroadcaster(self)
        self.path_msg = RosPath()
        self.path_msg.header.frame_id = self.frame_id

        self._reload_rows(initial=True)
        if not self.rows and not self.watch:
            raise RuntimeError(f"No rows in odometry CSV: {args.csv}")

        period = 1.0 / max(args.rate, 0.1)
        self.timer = self.create_timer(period, self._publish_next)
        playback_seconds = len(self.rows) / max(args.rate, 0.1) if self.rows else 0.0
        self.get_logger().info(
            f"Publishing {len(self.rows)} odometry rows at {args.rate:.1f} Hz "
            f"(~{playback_seconds:.1f}s per pass) to {args.odom_topic} and {args.path_topic}"
        )

    def _publish_next(self) -> None:
        if self.watch:
            self._reload_rows(initial=False)
        if not self.rows:
            return

        if self.index >= len(self.rows):
            if self.loop:
                self.index = 0
                self.path_msg.poses.clear()
            else:
                self.get_logger().info("Finished odometry CSV playback")
                rclpy.shutdown()
                return

        row = self.rows[self.index]
        stamp = self.get_clock().now().to_msg()
        odom = self._make_odom(row, stamp)
        pose = self._make_pose(row, stamp)
        transform = self._make_transform(row, stamp)

        self.odom_pub.publish(odom)
        self.tf_broadcaster.sendTransform(transform)
        if not self.success_only_path or row["pose_success"] == "1":
            self.path_msg.header.stamp = stamp
            self.path_msg.poses.append(pose)
        self.path_pub.publish(self.path_msg)
        self.index += 1

    def _reload_rows(self, initial: bool) -> None:
        if not self.csv_path.exists():
            if initial:
                self.get_logger().warn(f"Waiting for odometry CSV: {self.csv_path}")
            return
        mtime_ns = self.csv_path.stat().st_mtime_ns
        if not initial and mtime_ns == self.last_mtime_ns:
            return
        rows = _load_rows(self.csv_path)
        if not rows:
            return
        self.rows = rows
        self.index = 0
        self.path_msg = RosPath()
        self.path_msg.header.frame_id = self.frame_id
        self.last_mtime_ns = mtime_ns
        self.get_logger().info(f"Loaded {len(self.rows)} odometry rows from {self.csv_path}")

    def _make_odom(self, row: dict[str, str], stamp) -> Odometry:
        odom = Odometry()
        odom.header.stamp = stamp
        odom.header.frame_id = self.frame_id
        odom.child_frame_id = self.child_frame_id
        _fill_pose(odom.pose.pose, row, self.coordinate_frame)
        return odom

    def _make_pose(self, row: dict[str, str], stamp) -> PoseStamped:
        pose = PoseStamped()
        pose.header.stamp = stamp
        pose.header.frame_id = self.frame_id
        _fill_pose(pose.pose, row, self.coordinate_frame)
        return pose

    def _make_transform(self, row: dict[str, str], stamp) -> TransformStamped:
        transform = TransformStamped()
        transform.header.stamp = stamp
        transform.header.frame_id = self.frame_id
        transform.child_frame_id = self.child_frame_id
        position, quaternion = _row_pose(row, self.coordinate_frame)
        transform.transform.translation.x = position[0]
        transform.transform.translation.y = position[1]
        transform.transform.translation.z = position[2]
        transform.transform.rotation.x = quaternion[0]
        transform.transform.rotation.y = quaternion[1]
        transform.transform.rotation.z = quaternion[2]
        transform.transform.rotation.w = quaternion[3]
        return transform


def _fill_pose(pose, row: dict[str, str], coordinate_frame: str = "ros") -> None:
    position, quaternion = _row_pose(row, coordinate_frame)
    pose.position.x = position[0]
    pose.position.y = position[1]
    pose.position.z = position[2]
    pose.orientation.x = quaternion[0]
    pose.orientation.y = quaternion[1]
    pose.orientation.z = quaternion[2]
    pose.orientation.w = quaternion[3]


def _row_pose(row: dict[str, str], coordinate_frame: str) -> tuple[tuple[float, float, float], tuple[float, float, float, float]]:
    position = (float(row["x"]), float(row["y"]), float(row["z"]))
    quaternion = (
        float(row["qx"]),
        float(row["qy"]),
        float(row["qz"]),
        float(row["qw"]),
    )
    if coordinate_frame in {"opencv", "raw"}:
        return position, _normalize_quaternion(quaternion)
    if coordinate_frame == "flip-y":
        return (position[0], -position[1], position[2]), _normalize_quaternion(quaternion)
    if coordinate_frame != "ros":
        raise ValueError(f"Unsupported coordinate frame: {coordinate_frame}")

    # CSV odometry is in OpenCV optical coordinates: x right, y down, z forward.
    # RViz expects ROS body/map style: x forward, y left, z up.
    ros_position = (position[2], -position[0], -position[1])
    rotation = _quaternion_to_matrix(quaternion)
    converted = _matmul(_matmul(_OPENCV_OPTICAL_TO_ROS, rotation), _transpose(_OPENCV_OPTICAL_TO_ROS))
    return ros_position, _matrix_to_quaternion(converted)


_OPENCV_OPTICAL_TO_ROS = (
    (0.0, 0.0, 1.0),
    (-1.0, 0.0, 0.0),
    (0.0, -1.0, 0.0),
)


def _quaternion_to_matrix(quaternion: tuple[float, float, float, float]) -> tuple[tuple[float, float, float], ...]:
    qx, qy, qz, qw = _normalize_quaternion(quaternion)
    xx = qx * qx
    yy = qy * qy
    zz = qz * qz
    xy = qx * qy
    xz = qx * qz
    yz = qy * qz
    wx = qw * qx
    wy = qw * qy
    wz = qw * qz
    return (
        (1.0 - 2.0 * (yy + zz), 2.0 * (xy - wz), 2.0 * (xz + wy)),
        (2.0 * (xy + wz), 1.0 - 2.0 * (xx + zz), 2.0 * (yz - wx)),
        (2.0 * (xz - wy), 2.0 * (yz + wx), 1.0 - 2.0 * (xx + yy)),
    )


def _matrix_to_quaternion(rotation: tuple[tuple[float, float, float], ...]) -> tuple[float, float, float, float]:
    trace = rotation[0][0] + rotation[1][1] + rotation[2][2]
    if trace > 0.0:
        scale = math.sqrt(trace + 1.0) * 2.0
        qw = 0.25 * scale
        qx = (rotation[2][1] - rotation[1][2]) / scale
        qy = (rotation[0][2] - rotation[2][0]) / scale
        qz = (rotation[1][0] - rotation[0][1]) / scale
    elif rotation[0][0] > rotation[1][1] and rotation[0][0] > rotation[2][2]:
        scale = math.sqrt(1.0 + rotation[0][0] - rotation[1][1] - rotation[2][2]) * 2.0
        qw = (rotation[2][1] - rotation[1][2]) / scale
        qx = 0.25 * scale
        qy = (rotation[0][1] + rotation[1][0]) / scale
        qz = (rotation[0][2] + rotation[2][0]) / scale
    elif rotation[1][1] > rotation[2][2]:
        scale = math.sqrt(1.0 + rotation[1][1] - rotation[0][0] - rotation[2][2]) * 2.0
        qw = (rotation[0][2] - rotation[2][0]) / scale
        qx = (rotation[0][1] + rotation[1][0]) / scale
        qy = 0.25 * scale
        qz = (rotation[1][2] + rotation[2][1]) / scale
    else:
        scale = math.sqrt(1.0 + rotation[2][2] - rotation[0][0] - rotation[1][1]) * 2.0
        qw = (rotation[1][0] - rotation[0][1]) / scale
        qx = (rotation[0][2] + rotation[2][0]) / scale
        qy = (rotation[1][2] + rotation[2][1]) / scale
        qz = 0.25 * scale
    return _normalize_quaternion((qx, qy, qz, qw))


def _normalize_quaternion(quaternion: tuple[float, float, float, float]) -> tuple[float, float, float, float]:
    norm = math.sqrt(sum(value * value for value in quaternion))
    if norm == 0.0:
        return (0.0, 0.0, 0.0, 1.0)
    return tuple(value / norm for value in quaternion)


def _matmul(
    left: tuple[tuple[float, float, float], ...],
    right: tuple[tuple[float, float, float], ...],
) -> tuple[tuple[float, float, float], ...]:
    return tuple(
        tuple(sum(left[row][k] * right[k][col] for k in range(3)) for col in range(3))
        for row in range(3)
    )


def _transpose(matrix: tuple[tuple[float, float, float], ...]) -> tuple[tuple[float, float, float], ...]:
    return tuple(tuple(matrix[row][col] for row in range(3)) for col in range(3))


def _load_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as csv_file:
        return list(csv.DictReader(csv_file))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Publish VIO frontend odometry CSV to ROS2/RViz.")
    parser.add_argument("--csv", type=Path, default=Path("outputs/live/latest_odometry.csv"))
    parser.add_argument(
        "--rate",
        type=float,
        default=60.0,
        help="Odometry rows published per second. 60 Hz replays 3100 frame poses in about 52 seconds.",
    )
    parser.add_argument("--loop", action="store_true")
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--success-only-path", action="store_true")
    parser.add_argument("--frame-id", default="map")
    parser.add_argument("--child-frame-id", default="camera_link")
    parser.add_argument(
        "--coordinate-frame",
        choices=("ros", "opencv", "raw", "flip-y"),
        default="ros",
        help=(
            "ros: convert CSV OpenCV optical poses to RViz/map coordinates. "
            "opencv/raw: publish CSV coordinates directly with no axis conversion. "
            "flip-y: publish direct coordinates with only Y sign inverted."
        ),
    )
    parser.add_argument("--odom-topic", default="/visual_odom")
    parser.add_argument("--path-topic", default="/local_path")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rclpy.init()
    node = OdometryCsvPublisher(args)
    try:
        rclpy.spin(node)
    finally:
        if rclpy.ok():
            node.destroy_node()
            rclpy.shutdown()


if __name__ == "__main__":
    main()
